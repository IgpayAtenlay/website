# website

<a href="https://igpayatenlay.github.io/website/">Link</a>

To Do

<li>Add picture of myself to about me page</li>
<li>Make pretty with CSS</li>
<li>Make links to github</li>
<li>Make the pages interactive
    <ul>
    <li>Nomai</li>
    <li>Slitherlink solver</li>
    </ul>
</li>
<li>Edit text to sound cooler</li>